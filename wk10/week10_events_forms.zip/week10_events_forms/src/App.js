import logo from './logo.svg';
import './App.css';
import Login from './components/Login'
import SignUp from './components/SignUp';

function App() {
  return (
    <div>
      <h1>Events and Forms</h1>
      <Login />
      <SignUp />
    </div>
  );
}

export default App;
